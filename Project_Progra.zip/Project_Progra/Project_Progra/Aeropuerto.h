#pragma once
#include "ConectarBD.h"
#include "Modificar_Aeropuerto.h"

namespace Project_Progra {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de Aeropuerto
	/// </summary>
	public ref class Aeropuerto : public System::Windows::Forms::Form
	{
	public:
		Aeropuerto(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
			this->data2 = gcnew ConectarBD();
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~Aeropuerto()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	protected:
	private: System::Windows::Forms::Button^ btn_guardar;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ txt_nombre;
	private: System::Windows::Forms::TextBox^ txt_ciudad;


	private: System::Windows::Forms::TextBox^ txt_codigo;

	private: System::Windows::Forms::Label^ label1;
	private: ConectarBD^ data2;
	private: System::Windows::Forms::Button^ btn_eliminar;

	protected:

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle1 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle2 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->btn_guardar = (gcnew System::Windows::Forms::Button());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txt_nombre = (gcnew System::Windows::Forms::TextBox());
			this->txt_ciudad = (gcnew System::Windows::Forms::TextBox());
			this->txt_codigo = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->btn_eliminar = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// dataGridView1
			// 
			this->dataGridView1->BackgroundColor = System::Drawing::Color::White;
			this->dataGridView1->BorderStyle = System::Windows::Forms::BorderStyle::None;
			dataGridViewCellStyle1->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle1->BackColor = System::Drawing::Color::Indigo;
			dataGridViewCellStyle1->Font = (gcnew System::Drawing::Font(L"Berlin Sans FB", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			dataGridViewCellStyle1->ForeColor = System::Drawing::Color::White;
			dataGridViewCellStyle1->SelectionBackColor = System::Drawing::Color::Indigo;
			dataGridViewCellStyle1->SelectionForeColor = System::Drawing::Color::White;
			dataGridViewCellStyle1->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->dataGridView1->ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			dataGridViewCellStyle2->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle2->BackColor = System::Drawing::Color::White;
			dataGridViewCellStyle2->Font = (gcnew System::Drawing::Font(L"Berlin Sans FB", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			dataGridViewCellStyle2->ForeColor = System::Drawing::Color::Black;
			dataGridViewCellStyle2->SelectionBackColor = System::Drawing::Color::Lavender;
			dataGridViewCellStyle2->SelectionForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(64)));
			dataGridViewCellStyle2->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->dataGridView1->DefaultCellStyle = dataGridViewCellStyle2;
			this->dataGridView1->Location = System::Drawing::Point(462, 86);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->ReadOnly = true;
			this->dataGridView1->RowHeadersVisible = false;
			this->dataGridView1->SelectionMode = System::Windows::Forms::DataGridViewSelectionMode::FullRowSelect;
			this->dataGridView1->Size = System::Drawing::Size(424, 275);
			this->dataGridView1->TabIndex = 16;
			this->dataGridView1->CellClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Aeropuerto::dataGridView1_CellClick);
			this->dataGridView1->DoubleClick += gcnew System::EventHandler(this, &Aeropuerto::dataGridView1_DoubleClick_1);
			// 
			// btn_guardar
			// 
			this->btn_guardar->BackColor = System::Drawing::Color::DarkCyan;
			this->btn_guardar->FlatAppearance->BorderSize = 0;
			this->btn_guardar->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_guardar->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_guardar->ForeColor = System::Drawing::Color::White;
			this->btn_guardar->Location = System::Drawing::Point(91, 371);
			this->btn_guardar->Name = L"btn_guardar";
			this->btn_guardar->Size = System::Drawing::Size(196, 38);
			this->btn_guardar->TabIndex = 15;
			this->btn_guardar->Text = L"Guardar";
			this->btn_guardar->UseVisualStyleBackColor = false;
			this->btn_guardar->Click += gcnew System::EventHandler(this, &Aeropuerto::btn_guardar_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(50, 182);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(73, 21);
			this->label4->TabIndex = 14;
			this->label4->Text = L"Nombre";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(54, 255);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(69, 21);
			this->label3->TabIndex = 13;
			this->label3->Text = L"Ciudad";
			// 
			// txt_nombre
			// 
			this->txt_nombre->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_nombre->Location = System::Drawing::Point(151, 179);
			this->txt_nombre->Name = L"txt_nombre";
			this->txt_nombre->Size = System::Drawing::Size(180, 27);
			this->txt_nombre->TabIndex = 12;
			// 
			// txt_ciudad
			// 
			this->txt_ciudad->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_ciudad->Location = System::Drawing::Point(151, 255);
			this->txt_ciudad->Name = L"txt_ciudad";
			this->txt_ciudad->Size = System::Drawing::Size(180, 27);
			this->txt_ciudad->TabIndex = 11;
			// 
			// txt_codigo
			// 
			this->txt_codigo->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_codigo->Location = System::Drawing::Point(151, 104);
			this->txt_codigo->Name = L"txt_codigo";
			this->txt_codigo->Size = System::Drawing::Size(180, 27);
			this->txt_codigo->TabIndex = 10;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(34, 107);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(111, 21);
			this->label1->TabIndex = 9;
			this->label1->Text = L"Codigo AITA";
			// 
			// btn_eliminar
			// 
			this->btn_eliminar->BackColor = System::Drawing::Color::Red;
			this->btn_eliminar->FlatAppearance->BorderSize = 0;
			this->btn_eliminar->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_eliminar->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_eliminar->ForeColor = System::Drawing::Color::White;
			this->btn_eliminar->Location = System::Drawing::Point(602, 415);
			this->btn_eliminar->Name = L"btn_eliminar";
			this->btn_eliminar->Size = System::Drawing::Size(151, 38);
			this->btn_eliminar->TabIndex = 17;
			this->btn_eliminar->Text = L"Eliminar";
			this->btn_eliminar->UseVisualStyleBackColor = false;
			this->btn_eliminar->Click += gcnew System::EventHandler(this, &Aeropuerto::btn_eliminar_Click);
			// 
			// Aeropuerto
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(941, 511);
			this->Controls->Add(this->btn_eliminar);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->btn_guardar);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txt_nombre);
			this->Controls->Add(this->txt_ciudad);
			this->Controls->Add(this->txt_codigo);
			this->Controls->Add(this->label1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"Aeropuerto";
			this->Text = L"Aeropuerto";
			this->Load += gcnew System::EventHandler(this, &Aeropuerto::Aeropuerto_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Aeropuerto_Load(System::Object^ sender, System::EventArgs^ e) {
		this->Consulta2();
	}

	public: void Consulta2() {
		this->data2->abrir();
		this->dataGridView1->DataSource = this->data2->getData2();
		this->data2->cerrar();
	}

	//crear aeropuerto
	private: System::Void btn_guardar_Click(System::Object^ sender, System::EventArgs^ e) {
		this->data2->abrir();
		this->data2->Insertar2(this->txt_codigo->Text, this->txt_nombre->Text, this->txt_ciudad->Text);
		this->data2->cerrar();
		this->Consulta2();
	}

	//modificar aeropuerto
	private: System::Void dataGridView1_DoubleClick(System::Object^ sender, System::EventArgs^ e) {
	
	}
private: System::Void dataGridView1_DoubleClick_1(System::Object^ sender, System::EventArgs^ e) {
	String^ codigo = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[0]->Value);
	String^ nombre = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[1]->Value);
	String^ ciudad = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[2]->Value);
	Project_Progra::Modificar_Aeropuerto^ form = gcnew Project_Progra::Modificar_Aeropuerto();
	form->txt_codigo->Text = codigo;
	form->txt_nombre->Text = nombre;
	form->txt_ciudad->Text = ciudad;
	form->ShowDialog();
	ConectarBD^ data = gcnew ConectarBD();
	data->abrir();
	data->ModificarAeropuerto(form->txt_codigo->Text, form->txt_nombre->Text, form->txt_ciudad->Text, codigo);
	data->cerrar();
	this->Consulta2();
}
		//boton eliminar
	private: System::Void btn_eliminar_Click(System::Object^ sender, System::EventArgs^ e) {
		//para conocer la fila celeccionada
		String^ nombre = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[1]->Value);
		ConectarBD^ data = gcnew ConectarBD();
		data->abrir();
		data->EliminarAerop(nombre);
		data->cerrar();
		this->Consulta2();
	}
		   //selecciona la celda y da clic en el boton borar para eliminar fila de registro
	private: System::Void dataGridView1_CellClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {
		String^ nombre = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[1]->Value);
	}
};
}
