#pragma once
#include "FormRegistro.h"
#include "FormVuelo.h"
#include "ConectarBD.h"


namespace CppCLRWinFormsProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			conecbd = gcnew ConectarBD();
			//TODO: Add the constructor code here
		}
	private: System::Windows::Forms::Button^ btn_abrir_registros;
	public:

	public:
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Button^ btn_abrir_vuelo;



	public:

	private:
		ConectarBD^ conecbd;

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btn_abrir_registros = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->btn_abrir_vuelo = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// btn_abrir_registros
			// 
			this->btn_abrir_registros->BackColor = System::Drawing::Color::White;
			this->btn_abrir_registros->Font = (gcnew System::Drawing::Font(L"Century Gothic", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_abrir_registros->Location = System::Drawing::Point(193, 240);
			this->btn_abrir_registros->Name = L"btn_abrir_registros";
			this->btn_abrir_registros->Size = System::Drawing::Size(160, 47);
			this->btn_abrir_registros->TabIndex = 0;
			this->btn_abrir_registros->Text = L"Registros";
			this->btn_abrir_registros->UseVisualStyleBackColor = false;
			this->btn_abrir_registros->Click += gcnew System::EventHandler(this, &Form1::btn_abrir_registros_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Berlin Sans FB Demi", 24, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::White;
			this->label1->Location = System::Drawing::Point(163, 104);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(223, 37);
			this->label1->TabIndex = 1;
			this->label1->Text = L"AEROPUERTO";
			// 
			// btn_abrir_vuelo
			// 
			this->btn_abrir_vuelo->BackColor = System::Drawing::Color::White;
			this->btn_abrir_vuelo->Font = (gcnew System::Drawing::Font(L"Century Gothic", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_abrir_vuelo->Location = System::Drawing::Point(170, 342);
			this->btn_abrir_vuelo->Name = L"btn_abrir_vuelo";
			this->btn_abrir_vuelo->Size = System::Drawing::Size(208, 47);
			this->btn_abrir_vuelo->TabIndex = 2;
			this->btn_abrir_vuelo->Text = L"Detalles de Vuelo";
			this->btn_abrir_vuelo->UseVisualStyleBackColor = false;
			this->btn_abrir_vuelo->Click += gcnew System::EventHandler(this, &Form1::btn_abrir_vuelo_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(40)), static_cast<System::Int32>(static_cast<System::Byte>(29)),
				static_cast<System::Int32>(static_cast<System::Byte>(105)));
			this->ClientSize = System::Drawing::Size(540, 461);
			this->Controls->Add(this->btn_abrir_vuelo);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btn_abrir_registros);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^ sender, System::EventArgs^ e) {
		//prueba para ver si abre la coneccoin
		try
		{
			conecbd->abrir();
		}
		catch (Exception^ e)
		{

		}
	}
	//metodo boton para abrir FromRegistro
	private: System::Void btn_abrir_registros_Click(System::Object^ sender, System::EventArgs^ e) {
		//objeto 
		Project_Progra::FormRegistro^ form2 = gcnew Project_Progra::FormRegistro();
		//cierra from1
		this->Visible = false;
		//cierra el formulario auntomaticmente al no tener ninguan interaccion
		form2->ShowDialog();
		//vuele a abrir From1 
		this->Visible = true;
	}
	//boton abrir FormVuelo
	private: System::Void btn_abrir_vuelo_Click(System::Object^ sender, System::EventArgs^ e) {
		Project_Progra::FormVuelo^ form3 = gcnew Project_Progra::FormVuelo();
		//cierra from1
		this->Visible = false;
		//cierra el formulario auntomaticmente al no tener ninguna interaccion
		form3->ShowDialog();
		//vuele a abrir From3 
		this->Visible = true;
	}
};
}
