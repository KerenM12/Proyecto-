#include "pch.h"
#include "FormRegistro.h"

