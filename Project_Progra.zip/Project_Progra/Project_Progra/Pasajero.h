#pragma once
#include "ConectarBD.h"
#include "Modificar_Pasajero.h"

namespace Project_Progra {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de Pasajero
	/// </summary>
	public ref class Pasajero : public System::Windows::Forms::Form
	{
	public:
		Pasajero(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
			this->data = gcnew ConectarBD();
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~Pasajero()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::TextBox^ txt_nombre;
	private: System::Windows::Forms::TextBox^ txt_telefono;
	private: System::Windows::Forms::TextBox^ txt_apellido;




	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Button^ btn_guardar;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	protected:
	private: ConectarBD^ data;
	private: System::Windows::Forms::Button^ btn_eliminar;




	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle1 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle2 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txt_nombre = (gcnew System::Windows::Forms::TextBox());
			this->txt_telefono = (gcnew System::Windows::Forms::TextBox());
			this->txt_apellido = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->btn_guardar = (gcnew System::Windows::Forms::Button());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->btn_eliminar = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(34, 86);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(73, 21);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Nombre";
			// 
			// txt_nombre
			// 
			this->txt_nombre->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_nombre->Location = System::Drawing::Point(128, 86);
			this->txt_nombre->Name = L"txt_nombre";
			this->txt_nombre->Size = System::Drawing::Size(180, 27);
			this->txt_nombre->TabIndex = 1;
			// 
			// txt_telefono
			// 
			this->txt_telefono->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_telefono->Location = System::Drawing::Point(128, 237);
			this->txt_telefono->Name = L"txt_telefono";
			this->txt_telefono->Size = System::Drawing::Size(180, 27);
			this->txt_telefono->TabIndex = 2;
			// 
			// txt_apellido
			// 
			this->txt_apellido->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_apellido->Location = System::Drawing::Point(128, 155);
			this->txt_apellido->Name = L"txt_apellido";
			this->txt_apellido->Size = System::Drawing::Size(180, 27);
			this->txt_apellido->TabIndex = 3;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(31, 237);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(76, 21);
			this->label3->TabIndex = 5;
			this->label3->Text = L"Telefono";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(31, 155);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(74, 21);
			this->label4->TabIndex = 6;
			this->label4->Text = L"Apellido";
			// 
			// btn_guardar
			// 
			this->btn_guardar->BackColor = System::Drawing::Color::DarkCyan;
			this->btn_guardar->FlatAppearance->BorderSize = 0;
			this->btn_guardar->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_guardar->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_guardar->ForeColor = System::Drawing::Color::White;
			this->btn_guardar->Location = System::Drawing::Point(77, 362);
			this->btn_guardar->Name = L"btn_guardar";
			this->btn_guardar->Size = System::Drawing::Size(196, 38);
			this->btn_guardar->TabIndex = 7;
			this->btn_guardar->Text = L"Guardar";
			this->btn_guardar->UseVisualStyleBackColor = false;
			this->btn_guardar->Click += gcnew System::EventHandler(this, &Pasajero::btn_guardar_Click);
			// 
			// dataGridView1
			// 
			this->dataGridView1->BackgroundColor = System::Drawing::Color::White;
			this->dataGridView1->BorderStyle = System::Windows::Forms::BorderStyle::None;
			dataGridViewCellStyle1->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle1->BackColor = System::Drawing::Color::Indigo;
			dataGridViewCellStyle1->Font = (gcnew System::Drawing::Font(L"Berlin Sans FB", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			dataGridViewCellStyle1->ForeColor = System::Drawing::Color::White;
			dataGridViewCellStyle1->SelectionBackColor = System::Drawing::Color::Indigo;
			dataGridViewCellStyle1->SelectionForeColor = System::Drawing::Color::White;
			dataGridViewCellStyle1->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->dataGridView1->ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			dataGridViewCellStyle2->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle2->BackColor = System::Drawing::Color::White;
			dataGridViewCellStyle2->Font = (gcnew System::Drawing::Font(L"Berlin Sans FB", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			dataGridViewCellStyle2->ForeColor = System::Drawing::Color::Black;
			dataGridViewCellStyle2->SelectionBackColor = System::Drawing::Color::Lavender;
			dataGridViewCellStyle2->SelectionForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(64)));
			dataGridViewCellStyle2->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->dataGridView1->DefaultCellStyle = dataGridViewCellStyle2;
			this->dataGridView1->Location = System::Drawing::Point(439, 68);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->ReadOnly = true;
			this->dataGridView1->RowHeadersVisible = false;
			this->dataGridView1->SelectionMode = System::Windows::Forms::DataGridViewSelectionMode::FullRowSelect;
			this->dataGridView1->Size = System::Drawing::Size(424, 284);
			this->dataGridView1->TabIndex = 8;
			this->dataGridView1->CellClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Pasajero::dataGridView1_CellClick);
			this->dataGridView1->DoubleClick += gcnew System::EventHandler(this, &Pasajero::dataGridView1_DoubleClick);
			// 
			// btn_eliminar
			// 
			this->btn_eliminar->BackColor = System::Drawing::Color::Red;
			this->btn_eliminar->FlatAppearance->BorderSize = 0;
			this->btn_eliminar->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_eliminar->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_eliminar->ForeColor = System::Drawing::Color::White;
			this->btn_eliminar->Location = System::Drawing::Point(632, 411);
			this->btn_eliminar->Name = L"btn_eliminar";
			this->btn_eliminar->Size = System::Drawing::Size(151, 38);
			this->btn_eliminar->TabIndex = 9;
			this->btn_eliminar->Text = L"Eliminar";
			this->btn_eliminar->UseVisualStyleBackColor = false;
			this->btn_eliminar->Click += gcnew System::EventHandler(this, &Pasajero::btn_eliminar_Click);
			// 
			// Pasajero
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(941, 511);
			this->Controls->Add(this->btn_eliminar);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->btn_guardar);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txt_apellido);
			this->Controls->Add(this->txt_telefono);
			this->Controls->Add(this->txt_nombre);
			this->Controls->Add(this->label1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"Pasajero";
			this->Text = L"Pasajero";
			this->Load += gcnew System::EventHandler(this, &Pasajero::Pasajero_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Pasajero_Load(System::Object^ sender, System::EventArgs^ e) {
		this->Consulta();
	}

	public: void Consulta() {
		this->data->abrir();
		this->dataGridView1->DataSource = this->data->getData();
		this->data->cerrar();
	}
		  //crear un nuevo pasajero
	private: System::Void btn_guardar_Click(System::Object^ sender, System::EventArgs^ e) {
		this->data->abrir();
		this->data->Insertarp(this->txt_nombre->Text, this->txt_apellido->Text, this->txt_telefono->Text);
		this->data->cerrar();
		this->Consulta();
	}

		//modificar pasajero
private: System::Void dataGridView1_DoubleClick(System::Object^ sender, System::EventArgs^ e) {
	String^ nombre = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[1]->Value);
	String^ apellido = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[2]->Value);
	String^ telefono = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[3]->Value);
	Project_Progra::Modificar_Pasajero^ form = gcnew Project_Progra::Modificar_Pasajero();
	form->txt_nombre->Text = nombre;
	form->txt_apellido->Text = apellido;
	form->txt_telefono->Text = telefono;
	form->ShowDialog();
	ConectarBD^ data = gcnew ConectarBD();
	data->abrir();
	data->Modificar(form->txt_nombre->Text, form->txt_apellido->Text, form->txt_telefono->Text, nombre);
	data->cerrar();
	this->Consulta();

}
	   //boton eliminar fila
	private: System::Void btn_eliminar_Click(System::Object^ sender, System::EventArgs^ e) {
		//para conocer la fila celeccionada
		String^ nombre = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[1]->Value);
		ConectarBD^ data = gcnew ConectarBD();
		data->abrir();
		data->Eliminar(nombre);
		data->cerrar();
		this->Consulta();

	}
	private: System::Void dataGridView1_CellClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {
		String^ nombre = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[1]->Value);

	}
};
}
