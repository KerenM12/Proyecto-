#pragma once

using namespace std;
using namespace System::Data;
using namespace System;
using namespace MySql::Data::MySqlClient;	//importa clase necesarias para la comunicacion con MySQL

ref class ConectarBD
{
private:
	String^ ConnectionD;	//cadena de conexion
	MySqlConnection^ connect;	//objeto que ayuda con la conexion a MySQL

public:
	//metodos
	ConectarBD();	//constructor de clase
	void abrir();	//metodo para abrir conexion con base de datos
	void cerrar();	//metodo para cerrar conexion

	// M�todos para obtener datos de la tabla FormVuelo
	DataTable^ getDataFV(); 

	//Metodos relacionados con tabla pasajero
	DataTable^ getData();// Obtiene datos de la tabla 
	void Insertarp(String^, String^, String^);// Inserta un nuevo registro
	void Modificar(String^, String^, String^, String^);//para modificar registro
	void Eliminar(String^);//eliminar registro

	//Metodos relacionados con tabla aeropuerto
	DataTable^ getData2();// Obtiene datos de la tabla 
	void Insertar2(String^, String^, String^);// Inserta un nuevo registro
	void ModificarAeropuerto(String^, String^, String^, String^);//para modificar registro
	void EliminarAerop(String^);//eliminar registro

	//Metodos relacionados con tabla aerolinea
	DataTable^ getData3();// Obtiene datos de la tabla 
	void Insertar3(String^, String^);// Inserta un nuevo registro
	void ModificarAerolinea(String^, String^, String^);//para modificar registro
	void EliminarAerol(String^);//eliminar registro

	//Metodos relacionados con tabla reservacion
	DataTable^ getData4();// Obtiene datos de la tabla 
	void Insertar4(String^, String^, String^, String^);// Inserta un nuevo registro
	void ModificarReservacion(String^, String^, String^, String^, String^);//para modificar registro
	void EliminarReserva(String^);//eliminar registro
	
	//Metodos relacionados con tabla vuelo
	DataTable^ getData5();// Obtiene datos de la tabla 
	void Insertar5(String^, String^, String^, String^, String^, String^);// Inserta un nuevo registro
	void ModificarVuelo(String^, String^, String^, String^, String^, String^, String^ );//para modificar registro
	void EliminarVuelo(String^);//eliminar registro

};

