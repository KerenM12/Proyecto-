#pragma once

namespace Project_Progra {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de Modificar_Vuelo
	/// </summary>
	public ref class Modificar_Vuelo : public System::Windows::Forms::Form
	{
	public:
		Modificar_Vuelo(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~Modificar_Vuelo()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ btn_cancelar;
	protected:
	private: System::Windows::Forms::Button^ btn_guardar;
	private: System::Windows::Forms::Label^ label5;
	public: System::Windows::Forms::TextBox^ txt_abordaje;
	public: System::Windows::Forms::TextBox^ txt_salida;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	public: System::Windows::Forms::TextBox^ txt_llegada;
	public: System::Windows::Forms::TextBox^ txt_destino;
	private: System::Windows::Forms::Label^ label4;
	public: System::Windows::Forms::TextBox^ txt_aerolinea;
	public: System::Windows::Forms::TextBox^ txt_origen;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label7;

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btn_cancelar = (gcnew System::Windows::Forms::Button());
			this->btn_guardar = (gcnew System::Windows::Forms::Button());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->txt_abordaje = (gcnew System::Windows::Forms::TextBox());
			this->txt_salida = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txt_llegada = (gcnew System::Windows::Forms::TextBox());
			this->txt_destino = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txt_aerolinea = (gcnew System::Windows::Forms::TextBox());
			this->txt_origen = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// btn_cancelar
			// 
			this->btn_cancelar->BackColor = System::Drawing::Color::Red;
			this->btn_cancelar->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_cancelar->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_cancelar->ForeColor = System::Drawing::Color::White;
			this->btn_cancelar->Location = System::Drawing::Point(292, 362);
			this->btn_cancelar->Name = L"btn_cancelar";
			this->btn_cancelar->Size = System::Drawing::Size(147, 38);
			this->btn_cancelar->TabIndex = 26;
			this->btn_cancelar->Text = L"Cancelar";
			this->btn_cancelar->UseVisualStyleBackColor = false;
			this->btn_cancelar->Click += gcnew System::EventHandler(this, &Modificar_Vuelo::btn_cancelar_Click);
			// 
			// btn_guardar
			// 
			this->btn_guardar->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->btn_guardar->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_guardar->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_guardar->ForeColor = System::Drawing::Color::White;
			this->btn_guardar->Location = System::Drawing::Point(59, 362);
			this->btn_guardar->Name = L"btn_guardar";
			this->btn_guardar->Size = System::Drawing::Size(147, 38);
			this->btn_guardar->TabIndex = 25;
			this->btn_guardar->Text = L"Guardar";
			this->btn_guardar->UseVisualStyleBackColor = false;
			this->btn_guardar->Click += gcnew System::EventHandler(this, &Modificar_Vuelo::btn_guardar_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(78, 49);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(150, 21);
			this->label5->TabIndex = 60;
			this->label5->Text = L"Hora de Abordaje";
			// 
			// txt_abordaje
			// 
			this->txt_abordaje->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_abordaje->Location = System::Drawing::Point(234, 46);
			this->txt_abordaje->Name = L"txt_abordaje";
			this->txt_abordaje->Size = System::Drawing::Size(180, 27);
			this->txt_abordaje->TabIndex = 59;
			// 
			// txt_salida
			// 
			this->txt_salida->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_salida->Location = System::Drawing::Point(234, 103);
			this->txt_salida->Name = L"txt_salida";
			this->txt_salida->Size = System::Drawing::Size(180, 27);
			this->txt_salida->TabIndex = 58;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(113, 106);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(57, 21);
			this->label6->TabIndex = 57;
			this->label6->Text = L"Salida";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(108, 155);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(74, 21);
			this->label2->TabIndex = 56;
			this->label2->Text = L"Llegada";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(65, 254);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(163, 21);
			this->label3->TabIndex = 55;
			this->label3->Text = L"Aeropuerto Destino";
			// 
			// txt_llegada
			// 
			this->txt_llegada->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_llegada->Location = System::Drawing::Point(234, 152);
			this->txt_llegada->Name = L"txt_llegada";
			this->txt_llegada->Size = System::Drawing::Size(180, 27);
			this->txt_llegada->TabIndex = 54;
			// 
			// txt_destino
			// 
			this->txt_destino->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_destino->Location = System::Drawing::Point(234, 251);
			this->txt_destino->Name = L"txt_destino";
			this->txt_destino->Size = System::Drawing::Size(180, 27);
			this->txt_destino->TabIndex = 53;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(108, 306);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(85, 21);
			this->label4->TabIndex = 52;
			this->label4->Text = L"Aerolinea";
			// 
			// txt_aerolinea
			// 
			this->txt_aerolinea->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_aerolinea->Location = System::Drawing::Point(234, 303);
			this->txt_aerolinea->Name = L"txt_aerolinea";
			this->txt_aerolinea->Size = System::Drawing::Size(180, 27);
			this->txt_aerolinea->TabIndex = 51;
			// 
			// txt_origen
			// 
			this->txt_origen->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_origen->Location = System::Drawing::Point(234, 202);
			this->txt_origen->Name = L"txt_origen";
			this->txt_origen->Size = System::Drawing::Size(180, 27);
			this->txt_origen->TabIndex = 50;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(70, 202);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(158, 21);
			this->label1->TabIndex = 49;
			this->label1->Text = L"Aeropuerto Origen";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->Location = System::Drawing::Point(285, 19);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(217, 15);
			this->label7->TabIndex = 61;
			this->label7->Text = L"*Ingresar Hora en formato: HH:MM:SS";
			// 
			// Modificar_Vuelo
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightSteelBlue;
			this->ClientSize = System::Drawing::Size(514, 430);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->txt_abordaje);
			this->Controls->Add(this->txt_salida);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txt_llegada);
			this->Controls->Add(this->txt_destino);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txt_aerolinea);
			this->Controls->Add(this->txt_origen);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btn_cancelar);
			this->Controls->Add(this->btn_guardar);
			this->Name = L"Modificar_Vuelo";
			this->Text = L"Modificar_Vuelo";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btn_guardar_Click(System::Object^ sender, System::EventArgs^ e) {
		MessageBox::Show("Actualizado Correctamente");
		this->Close();
	}

	private: System::Void btn_cancelar_Click(System::Object^ sender, System::EventArgs^ e) {
		this->Close();
	}
};
}
