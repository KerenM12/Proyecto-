#pragma once
#include "ConectarBD.h"
#include "Modificar_Reservacion.h"

namespace Project_Progra {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de Reservacion
	/// </summary>
	public ref class Reservacion : public System::Windows::Forms::Form
	{
	public:
		Reservacion(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
			this->data4 = gcnew ConectarBD();
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~Reservacion()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::TextBox^ txt_asiento;
	private: System::Windows::Forms::TextBox^ txt_id_vuelo;
	protected:



	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::Button^ btn_guardar;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ txt_id_pasajero;
	private: System::Windows::Forms::TextBox^ txt_fecha;
	private: ConectarBD^ data4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Button^ btn_eliminar;





	protected:

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle1 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle2 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txt_asiento = (gcnew System::Windows::Forms::TextBox());
			this->txt_id_vuelo = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->btn_guardar = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txt_id_pasajero = (gcnew System::Windows::Forms::TextBox());
			this->txt_fecha = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->btn_eliminar = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(59, 297);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(69, 21);
			this->label4->TabIndex = 26;
			this->label4->Text = L"Asiento";
			// 
			// txt_asiento
			// 
			this->txt_asiento->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_asiento->Location = System::Drawing::Point(180, 294);
			this->txt_asiento->Name = L"txt_asiento";
			this->txt_asiento->Size = System::Drawing::Size(180, 27);
			this->txt_asiento->TabIndex = 25;
			// 
			// txt_id_vuelo
			// 
			this->txt_id_vuelo->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_id_vuelo->Location = System::Drawing::Point(180, 160);
			this->txt_id_vuelo->Name = L"txt_id_vuelo";
			this->txt_id_vuelo->Size = System::Drawing::Size(180, 27);
			this->txt_id_vuelo->TabIndex = 24;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(38, 163);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(116, 21);
			this->label1->TabIndex = 23;
			this->label1->Text = L"Codigo Vuelo";
			// 
			// dataGridView1
			// 
			this->dataGridView1->BackgroundColor = System::Drawing::Color::White;
			this->dataGridView1->BorderStyle = System::Windows::Forms::BorderStyle::None;
			dataGridViewCellStyle1->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle1->BackColor = System::Drawing::Color::Indigo;
			dataGridViewCellStyle1->Font = (gcnew System::Drawing::Font(L"Berlin Sans FB", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			dataGridViewCellStyle1->ForeColor = System::Drawing::Color::White;
			dataGridViewCellStyle1->SelectionBackColor = System::Drawing::Color::Indigo;
			dataGridViewCellStyle1->SelectionForeColor = System::Drawing::Color::White;
			dataGridViewCellStyle1->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->dataGridView1->ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			dataGridViewCellStyle2->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle2->BackColor = System::Drawing::Color::White;
			dataGridViewCellStyle2->Font = (gcnew System::Drawing::Font(L"Berlin Sans FB", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			dataGridViewCellStyle2->ForeColor = System::Drawing::Color::Black;
			dataGridViewCellStyle2->SelectionBackColor = System::Drawing::Color::Lavender;
			dataGridViewCellStyle2->SelectionForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(64)));
			dataGridViewCellStyle2->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->dataGridView1->DefaultCellStyle = dataGridViewCellStyle2;
			this->dataGridView1->Location = System::Drawing::Point(454, 77);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->ReadOnly = true;
			this->dataGridView1->RowHeadersVisible = false;
			this->dataGridView1->SelectionMode = System::Windows::Forms::DataGridViewSelectionMode::FullRowSelect;
			this->dataGridView1->Size = System::Drawing::Size(424, 275);
			this->dataGridView1->TabIndex = 34;
			this->dataGridView1->CellClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Reservacion::dataGridView1_CellClick);
			this->dataGridView1->DoubleClick += gcnew System::EventHandler(this, &Reservacion::dataGridView1_DoubleClick);
			// 
			// btn_guardar
			// 
			this->btn_guardar->BackColor = System::Drawing::Color::DarkCyan;
			this->btn_guardar->FlatAppearance->BorderSize = 0;
			this->btn_guardar->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_guardar->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_guardar->ForeColor = System::Drawing::Color::White;
			this->btn_guardar->Location = System::Drawing::Point(109, 402);
			this->btn_guardar->Name = L"btn_guardar";
			this->btn_guardar->Size = System::Drawing::Size(196, 38);
			this->btn_guardar->TabIndex = 33;
			this->btn_guardar->Text = L"Guardar";
			this->btn_guardar->UseVisualStyleBackColor = false;
			this->btn_guardar->Click += gcnew System::EventHandler(this, &Reservacion::btn_guardar_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(43, 102);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(99, 21);
			this->label2->TabIndex = 32;
			this->label2->Text = L"Id_Pasajero";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(63, 221);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(59, 21);
			this->label3->TabIndex = 31;
			this->label3->Text = L"Fecha";
			// 
			// txt_id_pasajero
			// 
			this->txt_id_pasajero->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_id_pasajero->Location = System::Drawing::Point(180, 99);
			this->txt_id_pasajero->Name = L"txt_id_pasajero";
			this->txt_id_pasajero->Size = System::Drawing::Size(180, 27);
			this->txt_id_pasajero->TabIndex = 30;
			// 
			// txt_fecha
			// 
			this->txt_fecha->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_fecha->Location = System::Drawing::Point(180, 221);
			this->txt_fecha->Name = L"txt_fecha";
			this->txt_fecha->Size = System::Drawing::Size(180, 27);
			this->txt_fecha->TabIndex = 29;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(170, 251);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(201, 15);
			this->label5->TabIndex = 42;
			this->label5->Text = L"*Ingresar en formato: YYYY-MM-DD";
			// 
			// btn_eliminar
			// 
			this->btn_eliminar->BackColor = System::Drawing::Color::Red;
			this->btn_eliminar->FlatAppearance->BorderSize = 0;
			this->btn_eliminar->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_eliminar->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_eliminar->ForeColor = System::Drawing::Color::White;
			this->btn_eliminar->Location = System::Drawing::Point(597, 417);
			this->btn_eliminar->Name = L"btn_eliminar";
			this->btn_eliminar->Size = System::Drawing::Size(151, 38);
			this->btn_eliminar->TabIndex = 43;
			this->btn_eliminar->Text = L"Eliminar";
			this->btn_eliminar->UseVisualStyleBackColor = false;
			this->btn_eliminar->Click += gcnew System::EventHandler(this, &Reservacion::btn_eliminar_Click);
			// 
			// Reservacion
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(941, 511);
			this->Controls->Add(this->btn_eliminar);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->btn_guardar);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txt_id_pasajero);
			this->Controls->Add(this->txt_fecha);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txt_asiento);
			this->Controls->Add(this->txt_id_vuelo);
			this->Controls->Add(this->label1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"Reservacion";
			this->Text = L"Reservacion";
			this->Load += gcnew System::EventHandler(this, &Reservacion::Reservacion_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Reservacion_Load(System::Object^ sender, System::EventArgs^ e) {
		this->Consulta4();
	}

	public: void Consulta4() {
		this->data4->abrir();
		this->dataGridView1->DataSource = this->data4->getData4();
		this->data4->cerrar();
	}
private: System::Void btn_guardar_Click(System::Object^ sender, System::EventArgs^ e) {
	this->data4->abrir();
	this->data4->Insertar4(this->txt_id_pasajero->Text, this->txt_id_vuelo->Text, this->txt_fecha->Text, this->txt_asiento->Text);
	this->data4->cerrar();
	this->Consulta4();
}
	   //modificar reservacion
private: System::Void dataGridView1_DoubleClick(System::Object^ sender, System::EventArgs^ e) {
	String^ pasajero = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[1]->Value);
	String^ vuelo = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[2]->Value);
	String^ fecha = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[3]->Value);
	String^ asiento = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[4]->Value);
	Project_Progra::Modificar_Reservacion^ form = gcnew Project_Progra::Modificar_Reservacion();
	form->txt_id_pasajero->Text = pasajero;
	form->txt_id_vuelo->Text = vuelo;
	form->txt_fecha->Text = fecha;
	form->txt_asiento->Text = asiento;
	form->ShowDialog();
	ConectarBD^ data = gcnew ConectarBD();
	data->abrir();
	data->ModificarReservacion(form->txt_id_pasajero->Text, form->txt_id_vuelo->Text, form->txt_fecha->Text, form->txt_asiento->Text, asiento);
	data->cerrar();
	this->Consulta4();
}
	   //boton eliminar
	private: System::Void btn_eliminar_Click(System::Object^ sender, System::EventArgs^ e) {
		//para conocer la fila celeccionada
		String^ asiento = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[4]->Value);
		ConectarBD^ data = gcnew ConectarBD();
		data->abrir();
		data->EliminarReserva(asiento);
		data->cerrar();
		this->Consulta4();
	}
	private: System::Void dataGridView1_CellClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {
		String^ asiento = Convert::ToString(dataGridView1->SelectedRows[0]->Cells[4]->Value);
	}
};
}
