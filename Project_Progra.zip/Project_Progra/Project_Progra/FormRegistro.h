#pragma once
using namespace std;
#include "Pasajero.h"
#include "Aeropuerto.h"
#include "Aerolinea.h"
#include "Reservacion.h"
#include "Vuelo.h"


namespace Project_Progra {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de FormRegistro
	/// </summary>
	public ref class FormRegistro : public System::Windows::Forms::Form
	{
	public:
		FormRegistro(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~FormRegistro()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^ panel_botones;
	protected:
	private: System::Windows::Forms::Panel^ panel_contenedor;
	private: System::Windows::Forms::Button^ btn_pasajeros;
	private: System::Windows::Forms::Panel^ margen;
	private: System::Windows::Forms::Button^ button4;

	private: System::Windows::Forms::Button^ btn_reservacion;
	private: System::Windows::Forms::Button^ btn_aerolineas;
	private: System::Windows::Forms::Button^ btn_aeropuertos;







	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->panel_botones = (gcnew System::Windows::Forms::Panel());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->btn_reservacion = (gcnew System::Windows::Forms::Button());
			this->btn_aerolineas = (gcnew System::Windows::Forms::Button());
			this->btn_aeropuertos = (gcnew System::Windows::Forms::Button());
			this->btn_pasajeros = (gcnew System::Windows::Forms::Button());
			this->margen = (gcnew System::Windows::Forms::Panel());
			this->panel_contenedor = (gcnew System::Windows::Forms::Panel());
			this->panel_botones->SuspendLayout();
			this->SuspendLayout();
			// 
			// panel_botones
			// 
			this->panel_botones->BackColor = System::Drawing::Color::Indigo;
			this->panel_botones->Controls->Add(this->button4);
			this->panel_botones->Controls->Add(this->btn_reservacion);
			this->panel_botones->Controls->Add(this->btn_aerolineas);
			this->panel_botones->Controls->Add(this->btn_aeropuertos);
			this->panel_botones->Controls->Add(this->btn_pasajeros);
			this->panel_botones->Controls->Add(this->margen);
			this->panel_botones->Dock = System::Windows::Forms::DockStyle::Top;
			this->panel_botones->Location = System::Drawing::Point(0, 0);
			this->panel_botones->Name = L"panel_botones";
			this->panel_botones->Size = System::Drawing::Size(941, 44);
			this->panel_botones->TabIndex = 0;
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::White;
			this->button4->Dock = System::Windows::Forms::DockStyle::Left;
			this->button4->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button4->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button4->Location = System::Drawing::Point(508, 10);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(127, 34);
			this->button4->TabIndex = 5;
			this->button4->Text = L"Vuelos";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &FormRegistro::button4_Click);
			// 
			// btn_reservacion
			// 
			this->btn_reservacion->BackColor = System::Drawing::Color::White;
			this->btn_reservacion->Dock = System::Windows::Forms::DockStyle::Left;
			this->btn_reservacion->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_reservacion->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_reservacion->Location = System::Drawing::Point(381, 10);
			this->btn_reservacion->Name = L"btn_reservacion";
			this->btn_reservacion->Size = System::Drawing::Size(127, 34);
			this->btn_reservacion->TabIndex = 4;
			this->btn_reservacion->Text = L"Reservacion";
			this->btn_reservacion->UseVisualStyleBackColor = false;
			this->btn_reservacion->Click += gcnew System::EventHandler(this, &FormRegistro::btn_reservacion_Click);
			// 
			// btn_aerolineas
			// 
			this->btn_aerolineas->BackColor = System::Drawing::Color::White;
			this->btn_aerolineas->Dock = System::Windows::Forms::DockStyle::Left;
			this->btn_aerolineas->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_aerolineas->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_aerolineas->Location = System::Drawing::Point(254, 10);
			this->btn_aerolineas->Name = L"btn_aerolineas";
			this->btn_aerolineas->Size = System::Drawing::Size(127, 34);
			this->btn_aerolineas->TabIndex = 3;
			this->btn_aerolineas->Text = L"Aerolineas";
			this->btn_aerolineas->UseVisualStyleBackColor = false;
			this->btn_aerolineas->Click += gcnew System::EventHandler(this, &FormRegistro::btn_aerolineas_Click);
			// 
			// btn_aeropuertos
			// 
			this->btn_aeropuertos->BackColor = System::Drawing::Color::White;
			this->btn_aeropuertos->Dock = System::Windows::Forms::DockStyle::Left;
			this->btn_aeropuertos->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_aeropuertos->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_aeropuertos->Location = System::Drawing::Point(127, 10);
			this->btn_aeropuertos->Name = L"btn_aeropuertos";
			this->btn_aeropuertos->Size = System::Drawing::Size(127, 34);
			this->btn_aeropuertos->TabIndex = 2;
			this->btn_aeropuertos->Text = L"Aeropuertos";
			this->btn_aeropuertos->UseVisualStyleBackColor = false;
			this->btn_aeropuertos->Click += gcnew System::EventHandler(this, &FormRegistro::btn_aeropuertos_Click);
			// 
			// btn_pasajeros
			// 
			this->btn_pasajeros->BackColor = System::Drawing::Color::White;
			this->btn_pasajeros->Dock = System::Windows::Forms::DockStyle::Left;
			this->btn_pasajeros->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_pasajeros->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_pasajeros->Location = System::Drawing::Point(0, 10);
			this->btn_pasajeros->Name = L"btn_pasajeros";
			this->btn_pasajeros->Size = System::Drawing::Size(127, 34);
			this->btn_pasajeros->TabIndex = 1;
			this->btn_pasajeros->Text = L"Pasajeros";
			this->btn_pasajeros->UseVisualStyleBackColor = false;
			this->btn_pasajeros->Click += gcnew System::EventHandler(this, &FormRegistro::btn_pasajeros_Click);
			// 
			// margen
			// 
			this->margen->Dock = System::Windows::Forms::DockStyle::Top;
			this->margen->Location = System::Drawing::Point(0, 0);
			this->margen->Name = L"margen";
			this->margen->Size = System::Drawing::Size(941, 10);
			this->margen->TabIndex = 0;
			// 
			// panel_contenedor
			// 
			this->panel_contenedor->BackColor = System::Drawing::Color::White;
			this->panel_contenedor->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->panel_contenedor->Dock = System::Windows::Forms::DockStyle::Fill;
			this->panel_contenedor->Location = System::Drawing::Point(0, 44);
			this->panel_contenedor->Name = L"panel_contenedor";
			this->panel_contenedor->Size = System::Drawing::Size(941, 511);
			this->panel_contenedor->TabIndex = 1;
			// 
			// FormRegistro
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(941, 555);
			this->Controls->Add(this->panel_contenedor);
			this->Controls->Add(this->panel_botones);
			this->Name = L"FormRegistro";
			this->Text = L"FormRegistro";
			this->Load += gcnew System::EventHandler(this, &FormRegistro::FormRegistro_Load);
			this->panel_botones->ResumeLayout(false);
			this->ResumeLayout(false);

		}
#pragma endregion
		//darle un tipo de dato a una variable que no se conoce el tipo de dato
		template<class T>

		//metodo para abrir Pasajero dentro del panel
		void AbrirPanel(T^ FormHijo) {
			//limpiar panel
			if (this->panel_contenedor->Controls->Count > 0) {
				this->panel_contenedor->Controls->Clear();
			}
				//pasar FormHijo dentro del panel
			FormHijo->TopLevel = false;
			FormHijo->Dock = DockStyle::Fill;
			//el panel a�adira como nuevo control,  FormHijo
			this->panel_contenedor->Controls->Add(FormHijo);
			this->panel_contenedor->Tag = FormHijo;
			FormHijo->Show();
		}

	private: System::Void FormRegistro_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	
		   //abrir formulario Pasajero
	private: System::Void btn_pasajeros_Click(System::Object^ sender, System::EventArgs^ e) {
		this->AbrirPanel(gcnew Project_Progra::Pasajero());
	}
	
		   //abrir formulario  Aeropuerto
	private: System::Void btn_aeropuertos_Click(System::Object^ sender, System::EventArgs^ e) {
		this->AbrirPanel(gcnew Project_Progra::Aeropuerto());
	}

		   //abrir formulario  Aerolinea
	private: System::Void btn_aerolineas_Click(System::Object^ sender, System::EventArgs^ e) {
		this->AbrirPanel(gcnew Project_Progra::Aerolinea());
	}

		   //abrir formulario  reservacion
	private: System::Void btn_reservacion_Click(System::Object^ sender, System::EventArgs^ e) {
		this->AbrirPanel(gcnew Project_Progra::Reservacion());
	}

		   //abrir formulario  vuelo
	private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
		this->AbrirPanel(gcnew Project_Progra::Vuelo());
	}

};
}
