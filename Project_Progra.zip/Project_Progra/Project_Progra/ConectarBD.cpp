#include "pch.h"
#include "ConectarBD.h"
#include <iostream>

using namespace std;
using namespace System::Windows::Forms;
using namespace MySql::Data::MySqlClient;

//metodo constructor
//crea conexion con MySQL usando una cadena de conexion ConnectionD
ConectarBD::ConectarBD() { 
	this->ConnectionD = "Server = localhost; port = 3306; database = proyecto_final; uid = keren; password = MelK#19";
	this->connect = gcnew MySqlConnection(this->ConnectionD);
}

//metodo para abrir conexion
void ConectarBD::abrir() 
{
	this->connect->Open();
}

//para cerraar conexion
void ConectarBD::cerrar() 
{
	this->connect->Close();

}


// metodo para obtener datos de tabla informacion_completa
DataTable^ ConectarBD::getDataFV() {
	String^ sql = "select * from informacion_completa";
	MySqlCommand^ cursor = gcnew MySqlCommand(sql, this->connect);
	MySqlDataAdapter^ data = gcnew MySqlDataAdapter(cursor);
	DataTable^ tabla = gcnew DataTable();
	data->Fill(tabla);
	return tabla;
}



//metodo para obtener datos de tabla pasajero
DataTable^ ConectarBD::getData() {
	String^ sql = "select * from pasajero";
	MySqlCommand^ cursor = gcnew MySqlCommand(sql, this->connect);
	MySqlDataAdapter^ data = gcnew MySqlDataAdapter(cursor);
	DataTable^ tabla = gcnew DataTable();
	data->Fill(tabla);
	return tabla;
}

void ConectarBD::Insertarp(String^ n, String^ p, String^ t) {
	String^ sql = "insert into pasajero(nombre, apellido, telefono) values ('" + n + "', '" + p + "', '" + t + "')";
	MySqlCommand^ cursor = gcnew  MySqlCommand(sql, this->connect);
	try
	{
		cursor->ExecuteNonQuery();
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}

//metodo para obtener datos de tabla aeropuerto
DataTable^ ConectarBD::getData2() {
	String^ sql = "select * from aeropuerto";
	MySqlCommand^ cursor2 = gcnew MySqlCommand(sql, this->connect);
	MySqlDataAdapter^ data2 = gcnew MySqlDataAdapter(cursor2);
	DataTable^ tabla = gcnew DataTable();
	data2->Fill(tabla);
	return tabla;
}

void ConectarBD::Insertar2(String^ a, String^ n, String^ ci) {
	String^ sql = "insert into aeropuerto(cod_aeropuerto, nombre, ciudad) values ('" + a + "', '" + n + "', '" + ci + "')";
	MySqlCommand^ cursor2 = gcnew  MySqlCommand(sql, this->connect);
	try
	{
		cursor2->ExecuteNonQuery();
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}


// metodo para obtener datos de tabla aerolinea
DataTable ^ ConectarBD::getData3() {
	String^ sql = "select * from aerolinea";
	MySqlCommand^ cursor3 = gcnew MySqlCommand(sql, this->connect);
	MySqlDataAdapter^ data3 = gcnew MySqlDataAdapter(cursor3);
	DataTable^ tabla = gcnew DataTable();
	data3->Fill(tabla);
	return tabla;
}

void ConectarBD::Insertar3(String^ c, String^ n) {
	String^ sql = "insert into aerolinea(cod_aerolinea, nombre) values ('" + c + "', '" + n + "')";
	MySqlCommand^ cursor3 = gcnew  MySqlCommand(sql, this->connect);
	try
	{
		cursor3->ExecuteNonQuery();
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}

// metodo para obtener datos de tabla reservacion
DataTable^ ConectarBD::getData4() {
	String^ sql = "select * from reservacion";
	MySqlCommand^ cursor4 = gcnew MySqlCommand(sql, this->connect);
	MySqlDataAdapter^ data4 = gcnew MySqlDataAdapter(cursor4);
	DataTable^ tabla = gcnew DataTable();
	data4->Fill(tabla);
	return tabla;
}

void ConectarBD::Insertar4(String^ p, String^ v, String^ f, String^ a) {
	String^ sql = "insert into reservacion(id_pasajero, id_vuelo, fecha, asiento) values ('" + p + "', '" + v + "', '" + f + "', '" + a + "')";
	MySqlCommand^ cursor4 = gcnew  MySqlCommand(sql, this->connect);
	try
	{
		cursor4->ExecuteNonQuery();
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}


// metodo para obtener datos de tabla vuelo
DataTable^ ConectarBD::getData5() {
	String^ sql = "select * from vuelo";
	MySqlCommand^ cursor5 = gcnew MySqlCommand(sql, this->connect);
	MySqlDataAdapter^ data5 = gcnew MySqlDataAdapter(cursor5);
	DataTable^ tabla = gcnew DataTable();
	data5->Fill(tabla);
	return tabla;
}

void ConectarBD::Insertar5(String^ h, String^ s, String^ l, String^ o, String^ d, String^ a) {
	String^ sql = "insert into vuelo(hora_abordaje, hora_salida, hora_llegada, cod_aeropuerto_origen, cod_aeropuerto_destino, aerolinea) values ('" + h + "', '" + s + "', '" + l + "', '" + o + "', '" + d + "', '" + a + "')";
	MySqlCommand^ cursor5 = gcnew  MySqlCommand(sql, this->connect);
	try
	{
		cursor5->ExecuteNonQuery();
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}
//modificar tabla pasajero
void ConectarBD::Modificar(String^ n, String^ p, String^ t, String^ ref) {
	String^ sql = "update pasajero set nombre='" + n + "', apellido='" + p + "', telefono = '" + t + "' where nombre = '" + ref + "'";
	MySqlCommand^ cursor = gcnew  MySqlCommand(sql, this->connect);
	try
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		cursor->ExecuteNonQuery();
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}

//modificar tabla aeropuerto
void ConectarBD::ModificarAeropuerto(String^ c, String^ n, String^ l, String^ ref) {
	String^ sql = "update aeropuerto set cod_aeropuerto ='" + c + "', nombre ='" + n + "', ciudad = '" + l + "' where cod_aeropuerto = '" + ref + "'";
	MySqlCommand^ cursor = gcnew  MySqlCommand(sql, this->connect);
	try
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		cursor->ExecuteNonQuery();
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}

//modificar tabla aerolinea
void ConectarBD::ModificarAerolinea(String^ c, String^ n, String^ ref) {
	String^ sql = "update aerolinea set cod_aerolinea ='" + c + "', nombre ='" + n + "' where cod_aerolinea = '" + ref + "'";
	MySqlCommand^ cursor = gcnew  MySqlCommand(sql, this->connect);
	try
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		cursor->ExecuteNonQuery();
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}

//modificar tabla reservacion
void ConectarBD::ModificarReservacion(String^ p, String^ v, String^ f, String^ a, String^ ref) {
	String^ sql = "update reservacion set id_pasajero ='" + p + "', id_vuelo ='" + v + "', fecha = '" + f + "', asiento = '" + a + "' where asiento = '" + ref + "'";
	MySqlCommand^ cursor = gcnew  MySqlCommand(sql, this->connect);
	try
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		cursor->ExecuteNonQuery();
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}

//modificar tabla vuelo
void ConectarBD::ModificarVuelo(String^ ha, String^ s, String^ l, String^ ao, String^ ad, String^ al, String^ ref) {
	String^ sql = "update vuelo set hora_abordaje ='" + ha + "', hora_salida ='" + s + "', hora_llegada = '" + l + "', cod_aeropuerto_origen = '" + ao + "', cod_aeropuerto_destino = '" + ad + "', aerolinea = '" + al + "' where hora_abordaje = '" + ref + "'";
	MySqlCommand^ cursor = gcnew  MySqlCommand(sql, this->connect);
	try
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		cursor->ExecuteNonQuery();
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}
//metodo eliminar pasajeros
Void ConectarBD::Eliminar(String^ nombre) {
	String^ sql = " delete from pasajero where nombre = '" + nombre + "'";
	MySqlCommand^ cursor = gcnew  MySqlCommand(sql, this->connect);
	try
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		cursor->ExecuteNonQuery();
		MessageBox::Show("Eliminado correctamente");
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}

//metodo eliminar aeropuerto
Void ConectarBD::EliminarAerop(String^ nombre) {
	String^ sql = " delete from aeropuerto where nombre = '" + nombre + "'";
	MySqlCommand^ cursor = gcnew  MySqlCommand(sql, this->connect);
	try
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		cursor->ExecuteNonQuery();
		MessageBox::Show("Eliminado correctamente");
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}

// metodo eliminar aerolinea
Void ConectarBD::EliminarAerol(String ^ nombre) {
	String^ sql = " delete from aerolinea where nombre = '" + nombre + "'";
	MySqlCommand^ cursor = gcnew  MySqlCommand(sql, this->connect);
	try
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		cursor->ExecuteNonQuery();
		MessageBox::Show("Eliminado correctamente");
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}


// metodo eliminar Reservacion
Void ConectarBD::EliminarReserva(String^ asiento) {
	String^ sql = " delete from reservacion where asiento = '" + asiento + "'";
	MySqlCommand^ cursor = gcnew  MySqlCommand(sql, this->connect);
	try
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		cursor->ExecuteNonQuery();
		MessageBox::Show("Eliminado correctamente");
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}

// metodo eliminar Vuelo
Void ConectarBD::EliminarVuelo(String^ abordaje) {
	String^ sql = " delete from vuelo where hora_abordaje = '" + abordaje + "'";
	MySqlCommand^ cursor = gcnew  MySqlCommand(sql, this->connect);
	try
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		cursor->ExecuteNonQuery();
		MessageBox::Show("Eliminado correctamente");
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}


